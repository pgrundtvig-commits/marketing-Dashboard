import { TrendingUp, TrendingDown, Minus } from "lucide-react";

export default function KpiCard({ title, value, subtitle, delta, deltaPositiveIsGood = true, color = "green", onClick }) {
  const colorMap = {
    green: "border-green-500 bg-green-50",
    blue: "border-blue-500 bg-blue-50",
    amber: "border-amber-500 bg-amber-50",
    purple: "border-purple-500 bg-purple-50",
    rose: "border-rose-500 bg-rose-50",
  };

  const renderDelta = () => {
    if (delta === null || delta === undefined) return null;
    const val = parseFloat(delta.value);
    const isPositive = val > 0;
    const isGood = deltaPositiveIsGood ? isPositive : !isPositive;
    const Icon = isPositive ? TrendingUp : val < 0 ? TrendingDown : Minus;
    const textColor = val === 0 ? "text-gray-400" : isGood ? "text-green-600" : "text-red-500";
    return (
      <span className={`flex items-center gap-1 text-xs font-medium ${textColor}`}>
        <Icon className="w-3 h-3" />
        {Math.abs(val)}% vs prev period
      </span>
    );
  };

  return (
    <div
      className={`bg-white rounded-xl border-l-4 p-4 shadow-sm cursor-pointer hover:shadow-md transition-shadow ${colorMap[color]}`}
      onClick={onClick}
    >
      <p className="text-xs font-medium text-gray-500 uppercase tracking-wide mb-1">{title}</p>
      <p className="text-2xl font-bold text-gray-900 leading-tight">{value}</p>
      {subtitle && <p className="text-xs text-gray-500 mt-0.5">{subtitle}</p>}
      <div className="mt-2">{renderDelta()}</div>
    </div>
  );
}